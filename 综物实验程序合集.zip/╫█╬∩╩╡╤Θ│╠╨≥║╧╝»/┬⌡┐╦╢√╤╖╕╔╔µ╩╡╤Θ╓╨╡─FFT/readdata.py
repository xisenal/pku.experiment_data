def read():
    name=input("输入要读取的文本名(记得加txt):")
    I=[]
    Ic=[]
    t=[]
    with open(name,"r",encoding="utf-8") as file:
        for line in file:
            if line[0]=='D':
                continue
            else:
                strline=line.split()
                time_str=strline[1]
                I.append(eval(strline[2]))
                Ic.append(eval(strline[3]))
                h,m,s_ms=time_str.split(':')
                s,ms=s_ms.split('.')
                h=int(h)
                m=int(m)
                s=int(s)
                ms=int(ms)
                total_seconds=h*3600+m*60+s+ms/1000
                t.append(total_seconds)
    t0=t[0]
    times=[]
    for ts in t:
        times.append(ts-t0)
    return times,I,Ic

if __name__=='__main__':
    t,x,y=read()
    print(t,x,y)
