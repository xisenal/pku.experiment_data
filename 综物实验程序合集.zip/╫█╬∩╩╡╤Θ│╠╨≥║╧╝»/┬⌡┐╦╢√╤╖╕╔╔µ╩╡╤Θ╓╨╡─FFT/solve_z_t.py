from readdata import read
import numpy as np
import matplotlib.pyplot as plt

t,I,Ic=read()
Ic0=max(Ic)
