from readdata import read
import numpy as np
import matplotlib.pyplot as plt

t,I,Ic=read()
N=len(I)          #归一化系数，这里一般取数组长度
fft_I=np.fft.fftshift(np.fft.fft(I))/N
plt.plot(N,fft_I)
plt.show()


